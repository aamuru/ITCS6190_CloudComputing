import java.util.ArrayList;
import java.util.Collections;
import java.util.*;
import java.io.IOException;
import java.util.regex.Pattern;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

public class FullIndex extends Configured implements Tool {

	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(Index.class);
	
	//Creating objects for storing the posting so that operations like sort can be performed.
	public static class allPostings {
		String lineStart;
		String docName;

		public String getOffset() {
			return lineStart;
		}

		public void setOffset(String lineStart) {
			this.lineStart = lineStart;
		}

		public String getFileName() {
			return docName;
		}

		public void setFileName(String docName) {
			this.docName = docName;
		}

	}

	//Driver Code
	public int run(String[] args) throws Exception {
		Job task = new Job(new Configuration(), "IndexNposition");
		task.setJarByClass(this.getClass());
		// Use TextInputFormat, the default unless task.setInputFormatClass is used
		FileInputFormat.addInputPath(task, new Path(args[0]));
		FileOutputFormat.setOutputPath(task, new Path(args[1]));
		task.setMapperClass(documentPostingMap.class);
		task.setReducerClass(docPostingsReduce.class);
		System.out.println("Running the Mapper and Reducer");
		task.setOutputKeyClass(Text.class);
		task.setOutputValueClass(Text.class);
		return task.waitForCompletion(true) ? 0 : 1;
	}


	//Mapper to get the Documents and Posting for the key
	public static class documentPostingMap extends Mapper<LongWritable, Text, Text, Text> {
		@SuppressWarnings("unused")
		private final static IntWritable one = new IntWritable(1);
		@SuppressWarnings("unused")
		private Text key = new Text();
		private static final Pattern WORD_BOUNDARY = Pattern.compile("\\s*\\b\\s*");

		public void map(LongWritable lineStart, Text lineText, Context context) throws IOException, InterruptedException {
			String stmnt = lineText.toString();
			Text selectedKey = new Text();
			for (String key : WORD_BOUNDARY.split(stmnt)) {
				if (key.isEmpty()) {
					continue;
				}
				String docName = ((FileSplit) context.getInputSplit()).getPath().getName();
				Text fileNameValue = new Text(docName);
				selectedKey = new Text(key);
				StringBuffer stringBuff = new StringBuffer();
				stringBuff.append(fileNameValue + " | " + lineStart);
				Text value = new Text(stringBuff.toString());
				context.write(selectedKey, value);
			}
		}
	}


	//The set of posting and the documents are combined in docPostingsReduce
	public static class docPostingsReduce extends Reducer<Text, Text, Text, Text> {

		@Override
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			ArrayList<allPostings> postings = new ArrayList<allPostings>();
			StringBuffer strBuff = new StringBuffer();

			for (Text posting : values) {
				allPostings allpostings = new allPostings();
				String[] partOFfile = posting.toString().split(".txt | ");
				allpostings.setOffset(partOFfile[2]);
				allpostings.setFileName(partOFfile[0]);
				postings.add(allpostings);
				System.out.println("Document : " + allpostings.getFileName() + " Position  :" + allpostings.getOffset());
			}
			Collections.sort(postings, new Comparator<allPostings>() {

				@Override
				public int compare(allPostings arg0, allPostings arg1) {
					// TODO Auto-generated method stub
					return arg0.getFileName().compareToIgnoreCase(arg1.getFileName());
				}

			});
			strBuff.append(": ");
			int i=0;
			while(i < postings.size()) {
				strBuff.append(postings.get(i).getFileName());
				strBuff.append(".txt@");
				strBuff.append(postings.get(i).getOffset());
				if (i + 1 < postings.size()) {
					strBuff.append("+");
				}
				i++;
			}
			strBuff.append("+");
			Text sum = new Text(strBuff.toString());
			context.write(key, sum);
		}
	}

	
	public static void main(String[] args) throws Exception {
		int result = ToolRunner.run(new FullIndex(), args);
		System.exit(result);
	}
}
