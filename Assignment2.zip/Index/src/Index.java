import java.util.ArrayList;
import java.util.Collections;
import java.io.IOException;
import java.util.regex.Pattern;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;


public class Index extends Configured implements Tool {

  @SuppressWarnings("unused")
  private static final Logger LOG = Logger.getLogger(Index.class);
  
  public static void main(String[] args) throws Exception {
	    int result = ToolRunner.run(new Index(), args);
	    System.exit(result);
	  }


  //Driver Code
  public int run(String[] args) throws Exception {
    Job task =new Job(new Configuration(), "Index");
    task.setJarByClass(this.getClass());
    // Use TextInputFormat, the default unless task.setInputFormatClass is used
    FileInputFormat.addInputPath(task, new Path(args[0]));
    FileOutputFormat.setOutputPath(task, new Path(args[1]));
    task.setMapperClass(documentMapper.class);
    task.setReducerClass(documentReducer.class);
    System.out.println("Running the Mapper and Reducer");
    task.setOutputKeyClass(Text.class);
    task.setOutputValueClass(Text.class);	
    return task.waitForCompletion(true) ? 0 : 1;
  }



  //documentMapper runner the Mapper to map the word to the document
  public static class documentMapper extends Mapper<LongWritable,Text, Text, Text> {
    @SuppressWarnings("unused")
	private final static IntWritable one = new IntWritable(1);
    @SuppressWarnings("unused")
	private Text key = new Text();
    @SuppressWarnings("unused")
	private long recordCount = 0;    
    private static final Pattern WORD_BOUNDARY = Pattern.compile("\\s*\\b\\s*");

    public void map(LongWritable offset, Text lineText, Context context)
        throws IOException, InterruptedException {
      String line = lineText.toString();
      Text selectedKey = new Text();
      for (String key : WORD_BOUNDARY.split(line)) {
        if (key.isEmpty()) {
            continue;
        }
        String docName = ((FileSplit) context.getInputSplit()).getPath().getName();
        Text docNameValue = new Text(docName);

            selectedKey = new Text(key);
            System.out.println("Key \""+selectedKey+"\" is found in the Document "+docNameValue);
            context.write(selectedKey,docNameValue);
        }
    }
  }

  //documentReducer runner the reducer to combine the word and document
  public static class documentReducer extends Reducer<Text, Text, Text, Text> {
	  
	    @Override
	    public void reduce(Text key, Iterable<Text> values, Context context)

	        throws IOException, InterruptedException {
	    	StringBuffer strBuff = new StringBuffer();
	    	@SuppressWarnings("unused")
			boolean bool=true;
	    	Text multi = new Text("null") ;
	        ArrayList<String> al = new ArrayList<String>(); 
	        for (Text count : values) {
	          System.out.println("Key \""+key+"\" is found in the Document "+count);

	        String[] parts = count.toString().split(".txt");
	        if(multi.toString().contains(parts[0])) {
	        }else {
	        	al.add(parts[0]);
	       multi=new Text(parts[0]);
	        }      	
	      }
	      Collections.sort(al); 
          strBuff.append(": "+al.get(0)+ ".txt");
	      int i=1; 
	      while(i<al.size()){
	          System.out.println(al.get(i));
	          strBuff.append(",");
	          strBuff.append(al.get(i));
	          strBuff.append(".txt");
	          i++;
	          } 
	      strBuff.append(",");
	      Text sum=new Text(strBuff.toString());
	      context.write(key, sum);
	    }
	  }
  

  
}
