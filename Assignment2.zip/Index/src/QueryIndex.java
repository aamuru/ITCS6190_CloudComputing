import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.Text;
import org.apache.log4j.Logger;

public class QueryIndex extends Configured implements Tool {

	@SuppressWarnings("unused")
	private static final Logger LOG = Logger.getLogger(Index.class);

	public static void main(String[] args) throws Exception {
		Path path = new Path(new Path(args[2]) + ".txt");
		ArrayList<allPostings> queryWords = queryPostingsList(new Path(args[0]));
		@SuppressWarnings("unchecked")
		ArrayList<allPostings> index = queryPostings(new Path(args[1]));

		queryComparator(index, new Path(args[1]), queryWords, path);
	}

	public static class allPostings {
		String key;
		ArrayList<String> lineStart;
		ArrayList<String> docName;

		public String getWord() {
			return key;
		}

		public void setWord(String key) {
			this.key = key;
		}

		public ArrayList<String> getOffset() {
			return lineStart;
		}

		public void setOffset(ArrayList<String> lineStart) {
			this.lineStart = lineStart;
		}

		public ArrayList<String> getFileName() {
			return docName;
		}

		public void setFileName(ArrayList<String> docName) {
			this.docName = docName;
		}

	}

	public static class docPostings {
		String lineStart;
		String docName;

		public String getOffset() {
			return lineStart;
		}

		public void setOffset(String lineStart) {
			this.lineStart = lineStart;
		}

		public String getFileName() {
			return docName;
		}

		public void setFileName(String docName) {
			this.docName = docName;
		}

	}

	public int run(String[] args) throws Exception {
		Job tasks = new Job(new Configuration(), "QueryFullIndex");
		tasks.setJarByClass(this.getClass());
		FileInputFormat.addInputPath(tasks, new Path(args[0]));
		FileOutputFormat.setOutputPath(tasks, new Path(args[2]));
		System.out.println("Running mapper and Reducer");
		tasks.setOutputKeyClass(Text.class);
		tasks.setOutputValueClass(Text.class);
		@SuppressWarnings("unused")
		int flag = tasks.waitForCompletion(true) ? 0 : 1;
		@SuppressWarnings("unused")
		Path path = new Path(new Path(args[2]) + ".txt");
		@SuppressWarnings("unused")
		ArrayList<allPostings> queryWords = queryPostingsList(new Path(args[0]));
		return 0;

	}

	private static ArrayList<allPostings> queryPostingsList(Path path) throws IOException {
		// TODO Auto-generated method stub
		String name = path.toString();
		BufferedReader buffRead = null;
		ArrayList<allPostings> queryWords = new ArrayList<allPostings>();
		try {
			buffRead = new BufferedReader(new FileReader(name));
			@SuppressWarnings("unused")
			StringBuffer strBuff = new StringBuffer();
			String line = buffRead.readLine();
			@SuppressWarnings("unused")
			String[] parts = null;
			String[] partres = null;
			while (line != null) {
				@SuppressWarnings("unused")
				ArrayList<String> lineStart = new ArrayList<String>();
				@SuppressWarnings("unused")
				ArrayList<String> docName = new ArrayList<String>();
				partres = line.split(" ");

				int i = 0;
				while (i < partres.length) {
					allPostings allqueryPosting = new allPostings();
					allqueryPosting.setWord(partres[i]);
					queryWords.add(allqueryPosting);

					i++;
				}
				line = buffRead.readLine();
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			buffRead.close();
		}
		return queryWords;
	}

	// Comparing Query with doc entries
	private static void queryComparator(ArrayList<allPostings> index, Path path, ArrayList<allPostings> queryWords,
			Path Qpath) throws IOException {
		// TODO Auto-generated method stub
		File file = new File(Qpath.toString());

		@SuppressWarnings("unused")
		PrintWriter Pwriter = null;
		FileWriter Fwriter = null;

		try {
			Fwriter = new FileWriter(file);
			// Fwriter.write("Test data");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int i = 0;
		while (i < queryWords.size()) {
			StringBuilder strBuff = new StringBuilder();
			strBuff.append(queryWords.get(i).getWord() + " : ");
			for (int j = 0; j < index.size(); j++) {
				if (queryWords.get(i).getWord().contentEquals(index.get(j).getWord())) {
					boolean flag = true;
					for (int m = 0; m < index.get(j).getFileName().size(); m++) {
						if (!flag) {
							strBuff.append(System.getProperty("line.separator"));
							flag = true;
						}
						;
						strBuff.append(index.get(j).getFileName().get(m));
						strBuff.append(System.getProperty("line.separator"));
					}
					try {
						Fwriter.write(strBuff.toString());
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println(strBuff.toString());
					strBuff.setLength(0);
				}
			}
			i++;
		}
		Fwriter.close();
	}

	/// reading a a file from a path and at a given lineStart
	public static String accessFile(String file, int position) {
		String doc = null;
		try {
			RandomAccessFile fileStore = new RandomAccessFile(file, "rw");
			fileStore.seek(position);
			doc = fileStore.readLine();
			fileStore.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return doc;
	}

	// Processing query Postings
	@SuppressWarnings("rawtypes")
	private static ArrayList queryPostings(Path path) throws IOException {
		// TODO Auto-generated method stub
		String name = path.toString();
		BufferedReader buffRead = null;
		ArrayList<allPostings> queryWords = new ArrayList<allPostings>();
		try {
			buffRead = new BufferedReader(new FileReader(name));
			@SuppressWarnings("unused")
			StringBuffer strBuff = new StringBuffer();
			String line = buffRead.readLine();
			String[] parts = null;
			String[] partres = null;
			while (line != null) {
				ArrayList<String> docName = new ArrayList<String>();
				allPostings allqueryPosting = new allPostings();
				System.out.println("Statement =@" + line);
				if (line.equals("0")) {
					line = buffRead.readLine();
					continue;
				}
				parts = line.split("[: ]");
				if (parts[0].isEmpty()) {
					line = buffRead.readLine();
					continue;
				}
				String[] keyWord = parts[0].split("\t");
				allqueryPosting.setWord(keyWord[0]);
				System.out.println("Key :" + parts[0]);
				if ((parts.length < 2)) {
					line = buffRead.readLine();
					continue;
				}
				if (parts[2].isEmpty()) {
					line = buffRead.readLine();
					continue;
				}
				if (parts[2].isEmpty()) {
					partres = parts[3].split("[+]");
				} else {
					partres = parts[2].split("[+]");
				}
				int i = 0;
				while (i < partres.length) {
					System.out.println("Length :" + partres[i]);
					String[] partresult = partres[i].split("@");
					docName.add(partresult[0]);
					i++;
				}
				allqueryPosting.setFileName(docName);
				System.out.println("Key :" + allqueryPosting.getWord() + "Doc :" + allqueryPosting.getFileName()
						+ " Position :" + allqueryPosting.getOffset());
				queryWords.add(allqueryPosting);
				line = buffRead.readLine();
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			buffRead.close();
		}
		return queryWords;
	}

}
