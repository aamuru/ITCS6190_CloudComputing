//Adithi Amuru aamuru@uncc.edu

Note: The output folder need to be deleted befor running Index.java and FullIndex.java.

1. To run Index.java and FullIndex.java two arguments need to be given

Input folder: "Input"
output folder: "output"


2. To run QueryIndex.java and QueryFullIndex.java three arguments need to be given

query file: "query.txt"
input file: : "Index_all.txt"/"fullindex_all.txt"
output file: "output"


