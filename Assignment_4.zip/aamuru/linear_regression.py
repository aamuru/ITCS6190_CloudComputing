# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 13:03:20 2019

@author: Adithi
"""
import sys
import numpy as np
#import pandas as pd
import csv
from pyspark import SparkContext
import matplotlib.pyplot as plt 

def Xt_X(X):
	X = np.insert(np.matrix(X,dtype=float), 0, 1, axis=1)
	Xt=np.transpose(X)
	return (np.dot(Xt, X))


def Y_Xt(Y,X):
	X=np.insert(np.matrix(X, dtype=float), 0, 1, axis=1)
	Y=np.matrix(Y, dtype=float)
	Xi = np.transpose(X)
	return(np.dot(Xi, Y))

def prediction(X,B):
	print("X",X,"\nB",B)
	return (B[0]+B[1]*X)
	

def main():
	if len(sys.argv) !=2:
		print (sys.stderr, "Usage: linreg <datafile>")
		exit(-1)

	sc = SparkContext.getOrCreate()
	
	# Input yx file has y_i as the first element of each line 
	# and the remaining elements constitute x_i
	yxinputFile = sc.textFile("file:///"+sys.argv[1])
	yxlines = yxinputFile.map(lambda line: line.split(','))
	yxfirstline = yxlines.first()
	yxlength = len(yxfirstline)
	
	B=np.zeros(yxlength, dtype=float)
	#print(B)
	
	Xt_X_val=yxlines.map(lambda line: Xt_X(line[1:]))
	#print(Xt_X_val.collect())
	
	Y_Xt_val=yxlines.map(lambda line: Y_Xt(line[0],line[1:]))
	#print(Y_Xt_val.collect())
	
	Xt_X_sum=Xt_X_val.reduce(lambda Xi, Xj: np.add(Xi,Xj)) 
	Y_Xt_sum=Y_Xt_val.reduce(lambda Xi, Yi: np.add(Xi,Yi))
	
	B=np.dot(np.linalg.inv(Xt_X_sum),Y_Xt_sum)
	
	B=B.tolist()
	
	B0=B[0][0]
	B1=B[1][0]
	print('\nB0: '+str(B0)+'\nB1: '+str(B1)+"\n")
	
	y=[]
	x=[]
	y1=[]
	f=open("output.txt","a+")
	f.write("Value of Beta\n"+'\nB0 '+str(B0)+'\nB1 '+str(B1)+"\n")

	f.write("\nThe predicted Y values: \n")
	with open(sys.argv[1],'rt')as f:
		data = csv.reader(f)
		for row in data:
			x.append(float(row[1]))
			y1.append(float(row[0]))
			y.append(B0+(B1*float(row[1])))
			
	#print(len(y))
	f=open("output.txt","a+")
	for i in range(0,len(y)):
		f.write(str(y[i])+"\n")

	#print(y)
	#plt.plot(x,y1,'.')
	#plt.plot(x,y)
	#plt.savefig("out.png")
	#plt.show()
	sc.stop()
	
	
main()