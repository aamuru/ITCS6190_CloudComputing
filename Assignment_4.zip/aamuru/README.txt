README

1. The project contains two python files for the project:
	a. linear_regression.py, this can be run in DSBA cluster.
	b. linear_reg_with_plot.py, this can be run in the local system. This will output graph files showing the line drawn using the predicted values.
2. To run the files type: spark-submit linear_regression.py yxlin.csv/yxlin2.csv.
3. The folder also contains two png files showing the graph representations for the line equation predicted.
4. The output files contain the beta values calculated and the predicted Y values using this b values.